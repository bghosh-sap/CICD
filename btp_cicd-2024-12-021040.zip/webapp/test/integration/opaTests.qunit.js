/* global QUnit */

sap.ui.require(["btpcicd/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
