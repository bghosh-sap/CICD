sap.ui.define([
	"btp_cicd/test/unit/controller/ViewBG.controller"
], function () {
	"use strict";
});
